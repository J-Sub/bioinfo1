# This script is supposed to fail as a negative control for the master test.sh
exit 1;
