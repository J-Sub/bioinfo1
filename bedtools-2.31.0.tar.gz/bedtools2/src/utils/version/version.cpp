#include "version.h"
#include "version_git.h"

const char VERSION[] = VERSION_GIT;
