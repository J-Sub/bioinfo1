namespace BamTools {
}
